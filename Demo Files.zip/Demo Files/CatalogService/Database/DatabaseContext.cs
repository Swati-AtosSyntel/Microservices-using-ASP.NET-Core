﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CatalogService.Database
{
    public class DatabaseContext:DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options)
        {

        }
        public DbSet<Category> Categories { get; set; }

        public DbSet<Product> Products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                new Category
                {
                    CategoryId = 1,
                    Name = "Electronics"

                },
                new Category
                {
                    CategoryId = 2,
                    Name = "Clothes"

                },
                new Category
                {
                    CategoryId = 3,
                    Name = "Grocery"

                }
            );
            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    ProductId=123,
                    ProductName="Laptop",
                    Description="Electronic Appliances",
                    CategoryId=1
                    
                },
                new Product
                {
                    ProductId = 124,
                    ProductName = "Jeans",
                    Description = "Boy's Jeans",
                    CategoryId = 2

                },
                new Product
                {
                    ProductId = 125,
                    ProductName = "Sansung Mobile",
                    Description = "Electronics Appliances",
                    CategoryId = 1

                }
            );

        }

    }
}
